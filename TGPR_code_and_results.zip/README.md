# Trust-Gated Predictive Reallocation (TGPR)

Code, data, and manuscript for "Trust-Gated Predictive Reallocation: A Bayesian
Communication-Reliability Approach to Decentralized Multi-Robot Task Allocation
Under Lossy Networks" (target: Discover Robotics).

**Repository**: https://github.com/hasib1233333/Trust-Gated-Predictive-Reallocation
(currently just a placeholder README on GitHub — see "Publishing this package" below.)

## Revision history
- **v2** (current): addressed reviewer feedback — real GitHub URL in Declarations,
  95% CIs and pooled effect sizes added throughout Results, all inline formulas
  converted to numbered equations, Algorithm 1 rewritten in standard
  Require/Ensure form, a computational complexity analysis and table added,
  the channel model's exponential-decay assumption grounded against the
  log-distance path-loss literature, an explicit paragraph justifying the
  choice of baselines (and why CBBA/GA/RL methods weren't included), all
  figures regenerated at larger font size / thicker lines / clearer legends
  for print, and an explicit, honest statement that hardware/ROS 2 validation
  is the most important open gap rather than something quietly implied to
  have been done.
- **v1**: initial 16-page, 4-figure version.

## Publishing this package
I don't have push credentials for the GitHub repo above, so I can't publish
this myself. To make the code-availability link in the manuscript actually
resolve, clone the repo, copy this package's contents in, and push:
```
git clone https://github.com/hasib1233333/Trust-Gated-Predictive-Reallocation.git
cp -r code data figures manuscript README.md Trust-Gated-Predictive-Reallocation/
cd Trust-Gated-Predictive-Reallocation
git add -A && git commit -m "TGPR: code, data, and manuscript" && git push
```

## Structure
- `manuscript/` — `sn-article.tex` (Springer Nature `sn-jnl` class), `references.bib`,
  compiled `sn-article.pdf` (22 pages, 15 figures), and the figures used in the paper.
- `code/` — simulation engine and experiment scripts:
  - `engine.py` — world/channel model, robot/task definitions
  - `simulate.py` — episode simulator implementing NaiveCNP, BackoffCNP, PeriodicRecon, TGPR
  - `experiment.py` / `experiment_resume.py` — main sweep (5 channel scenarios × 2 team sizes × 120 seeds × 4 protocols)
  - `ablation.py` / `ablation_resume.py` — hardware-degraded-fraction ablation (5 fractions × 100 seeds × 4 protocols)
  - `trust_trace_experiment.py` — traces per-robot trust/timeout trajectories over the mission (40 seeds × 2 scenarios)
  - `param_sensitivity.py` — sweeps timeout multiplier `z` and trust decay `λ` (60 seeds/value)
  - `analyze.py` — Mann-Whitney U significance tests and summary tables
  - `plot_figures.py`, `plot_extra_figures.py`, `plot_trust_evolution.py`, `plot_param_sensitivity.py` — all figure generation, directly from logged CSVs/JSON
- `data/` — raw simulation logs (`main_sweep.csv`, `ablation_degraded_fraction.csv`,
  `trust_trace.json`, `param_sensitivity.csv`) and derived tables (`summary_table.csv`,
  `significance_tests.csv`).
- `figures/` — standalone copies of all 15 generated figures (schematic diagrams are
  TikZ, compiled directly into the PDF rather than as separate image files; the 10
  PNGs here are the data-driven ones).

## Reproducing
```
cd code
python3 experiment.py              # ~25 min single-core; writes data/main_sweep.csv
python3 ablation.py                # ~10 min single-core; writes data/ablation_degraded_fraction.csv
python3 trust_trace_experiment.py  # ~2 min; writes data/trust_trace.json
python3 param_sensitivity.py       # ~4 min; writes data/param_sensitivity.csv
python3 analyze.py                 # prints summary tables + significance tests
python3 plot_figures.py            # writes main sweep figures
python3 plot_extra_figures.py      # writes heatmap/boxplot/radar figures
python3 plot_trust_evolution.py    # writes trust evolution figure
python3 plot_param_sensitivity.py  # writes parameter sensitivity figure
```

## Honest summary of findings
TGPR reduces duplicate-execution waste (~24% relative) and per-completed-task
messaging overhead (~14% relative) versus a naive fixed-timeout auction, with both
advantages growing as channel quality worsens or hardware heterogeneity increases.
It does **not** improve overall completion rate — it is significantly worse than
the simplest baseline in poor/severe channel conditions, and this gap widens (not
narrows) as the fraction of hardware-degraded robots increases, contrary to our
original hypothesis. We traced this directly: under sustained high failure rates,
adaptive timeouts for all robots drift toward the cap and trust scores for healthy
vs. degraded robots converge rather than separate (`fig_trust_evolution.png`), and
a parameter sweep confirms the timeout multiplier `z` — not the trust decay rate —
is the lever controlling this trade-off (`fig_param_sensitivity.png`). See the
manuscript's Results and Discussion sections for the full account.

## Code availability placeholder
Replace this section with the actual GitHub URL once this repository is pushed,
and update the corresponding line in `manuscript/sn-article.tex` (Declarations →
Code availability) before submission.
