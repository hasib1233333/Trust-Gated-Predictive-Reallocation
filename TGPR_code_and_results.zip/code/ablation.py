import csv
import time
from simulate import run_episode

DEGRADED_FRACTIONS = [0.0, 0.1, 0.22, 0.35, 0.5]
PROTOCOLS = ["naive", "backoff", "periodic", "tgpr"]
N_SEEDS = 100
SCENARIO = "moderate"
N_ROBOTS = 20
OUT_PATH = "/home/claude/tgpr/data/ablation_degraded_fraction.csv"

FIELDNAMES = ["protocol", "degraded_fraction", "seed", "total_tasks", "completed",
              "expired", "completion_rate", "starvation_rate", "duplicate_rate",
              "mean_latency", "msgs_per_completed", "early_completion_rate",
              "late_completion_rate"]


def main():
    t0 = time.time()
    with open(OUT_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        for dfrac in DEGRADED_FRACTIONS:
            for seed in range(N_SEEDS):
                for proto in PROTOCOLS:
                    r = run_episode(proto, SCENARIO, N_ROBOTS, seed=seed + 9000,
                                     degraded_fraction=dfrac)
                    r["degraded_fraction"] = dfrac
                    row = {k: r[k] for k in FIELDNAMES}
                    writer.writerow(row)
            f.flush()
            print(f"done degraded_fraction={dfrac} ({time.time()-t0:.0f}s elapsed)", flush=True)
    print(f"ABLATION DONE in {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
