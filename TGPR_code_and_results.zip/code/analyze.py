import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("/home/claude/tgpr/data/main_sweep.csv")

METRICS = ["completion_rate", "duplicate_rate", "mean_latency", "msgs_per_completed",
           "starvation_rate"]

PROTO_ORDER = ["naive", "backoff", "periodic", "tgpr"]
SCEN_ORDER = ["excellent", "good", "moderate", "poor", "severe"]


def rank_biserial(x, y):
    """Effect size for Mann-Whitney U: rank-biserial correlation in [-1,1]."""
    n1, n2 = len(x), len(y)
    u, _ = stats.mannwhitneyu(x, y, alternative="two-sided")
    return 1 - (2 * u) / (n1 * n2)


def summary_table():
    rows = []
    for scen in SCEN_ORDER:
        for n_robots in sorted(df.n_robots.unique()):
            sub = df[(df.scenario == scen) & (df.n_robots == n_robots)]
            row = {"scenario": scen, "n_robots": n_robots}
            for proto in PROTO_ORDER:
                s = sub[sub.protocol == proto]
                row[f"{proto}_completion_mean"] = s.completion_rate.mean()
                row[f"{proto}_completion_std"] = s.completion_rate.std()
                row[f"{proto}_duplicate_mean"] = s.duplicate_rate.mean()
                row[f"{proto}_latency_mean"] = s.mean_latency.mean()
                row[f"{proto}_msgs_mean"] = s.msgs_per_completed.mean()
            rows.append(row)
    return pd.DataFrame(rows)


def significance_tests():
    rows = []
    for scen in SCEN_ORDER:
        for n_robots in sorted(df.n_robots.unique()):
            sub = df[(df.scenario == scen) & (df.n_robots == n_robots)]
            tgpr = sub[sub.protocol == "tgpr"]
            for baseline in ["naive", "backoff", "periodic"]:
                base = sub[sub.protocol == baseline]
                for metric in METRICS:
                    x = tgpr[metric].dropna().values
                    y = base[metric].dropna().values
                    if len(x) < 5 or len(y) < 5:
                        continue
                    try:
                        u, p = stats.mannwhitneyu(x, y, alternative="two-sided")
                        eff = rank_biserial(x, y)
                    except ValueError:
                        continue
                    rows.append(dict(
                        scenario=scen, n_robots=n_robots, baseline=baseline, metric=metric,
                        tgpr_mean=x.mean(), base_mean=y.mean(),
                        diff=x.mean() - y.mean(), p_value=p, rank_biserial=eff,
                        n_tgpr=len(x), n_base=len(y),
                    ))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    st = summary_table()
    st.to_csv("/home/claude/tgpr/data/summary_table.csv", index=False)
    sig = significance_tests()
    sig.to_csv("/home/claude/tgpr/data/significance_tests.csv", index=False)

    pd.set_option("display.width", 160)
    pd.set_option("display.max_columns", 20)
    print("=== Completion rate by scenario/team size ===")
    cols = ["scenario", "n_robots"] + [f"{p}_completion_mean" for p in PROTO_ORDER]
    print(st[cols].round(3).to_string(index=False))

    print("\n=== TGPR vs baselines: significant completion_rate differences (p<0.05) ===")
    sig_comp = sig[(sig.metric == "completion_rate") & (sig.p_value < 0.05)]
    print(sig_comp[["scenario", "n_robots", "baseline", "tgpr_mean", "base_mean", "diff",
                     "p_value", "rank_biserial"]].round(4).to_string(index=False))

    print("\n=== TGPR vs baselines: significant duplicate_rate differences (p<0.05) ===")
    sig_dup = sig[(sig.metric == "duplicate_rate") & (sig.p_value < 0.05)]
    print(sig_dup[["scenario", "n_robots", "baseline", "tgpr_mean", "base_mean", "diff",
                    "p_value", "rank_biserial"]].round(4).to_string(index=False))

    print("\n=== TGPR vs baselines: significant msgs_per_completed differences (p<0.05) ===")
    sig_msg = sig[(sig.metric == "msgs_per_completed") & (sig.p_value < 0.05)]
    print(sig_msg[["scenario", "n_robots", "baseline", "tgpr_mean", "base_mean", "diff",
                   "p_value", "rank_biserial"]].round(4).to_string(index=False))
