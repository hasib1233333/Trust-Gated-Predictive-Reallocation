import csv
import time
from simulate import run_episode

Z_VALUES = [1.0, 1.8, 2.5, 3.5]
DECAY_VALUES = [0.90, 0.97, 0.995]
N_SEEDS = 60
SCENARIO = "severe"
N_ROBOTS = 20
OUT_PATH = "/home/claude/tgpr/data/param_sensitivity.csv"

FIELDNAMES = ["sweep", "value", "seed", "completion_rate", "duplicate_rate",
              "msgs_per_completed", "mean_latency"]


def main():
    t0 = time.time()
    with open(OUT_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()

        # baseline (default z=1.8, decay=0.97) is already covered by z=1.8/decay=0.97 rows below

        for z in Z_VALUES:
            for seed in range(N_SEEDS):
                r = run_episode("tgpr", SCENARIO, N_ROBOTS, seed=seed + 11000,
                                 trust_kwargs={"z": z})
                writer.writerow(dict(sweep="z", value=z, seed=seed, **{k: r[k] for k in FIELDNAMES if k not in ("sweep", "value", "seed")}))
            f.flush()
            print(f"done z={z} ({time.time()-t0:.0f}s)", flush=True)

        for decay in DECAY_VALUES:
            for seed in range(N_SEEDS):
                r = run_episode("tgpr", SCENARIO, N_ROBOTS, seed=seed + 11000,
                                 trust_kwargs={"decay": decay})
                writer.writerow(dict(sweep="decay", value=decay, seed=seed, **{k: r[k] for k in FIELDNAMES if k not in ("sweep", "value", "seed")}))
            f.flush()
            print(f"done decay={decay} ({time.time()-t0:.0f}s)", flush=True)

    print(f"PARAM SENSITIVITY DONE in {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
