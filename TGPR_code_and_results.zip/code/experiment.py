import csv
import sys
import time
from simulate import run_episode

SCENARIOS = ["excellent", "good", "moderate", "poor", "severe"]
TEAM_SIZES = [15, 25]
PROTOCOLS = ["naive", "backoff", "periodic", "tgpr"]
N_SEEDS = 120
OUT_PATH = "/home/claude/tgpr/data/main_sweep.csv"

FIELDNAMES = ["protocol", "scenario", "n_robots", "seed", "total_tasks", "completed",
              "expired", "completion_rate", "starvation_rate", "duplicate_rate",
              "mean_latency", "median_latency", "total_messages", "msgs_per_completed",
              "wasted_exec_ticks", "episode_ticks", "early_completion_rate", "late_completion_rate"]


def main():
    t0 = time.time()
    n_done = 0
    n_total = len(SCENARIOS) * len(TEAM_SIZES) * len(PROTOCOLS) * N_SEEDS
    with open(OUT_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        for scen in SCENARIOS:
            for n_robots in TEAM_SIZES:
                for seed in range(N_SEEDS):
                    for proto in PROTOCOLS:
                        r = run_episode(proto, scen, n_robots, seed=seed + 5000)
                        row = {k: r[k] for k in FIELDNAMES}
                        writer.writerow(row)
                        n_done += 1
                f.flush()
                elapsed = time.time() - t0
                print(f"done scenario={scen} n_robots={n_robots}  "
                      f"({n_done}/{n_total}, {elapsed:.0f}s elapsed)", flush=True)
    print(f"ALL DONE in {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
