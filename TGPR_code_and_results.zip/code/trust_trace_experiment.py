import numpy as np
import json
from simulate import run_episode

N_SEEDS = 40
N_ROBOTS = 20
SCENARIOS = ["moderate", "severe"]
OUT_PATH = "/home/claude/tgpr/data/trust_trace.json"


def main():
    results = {}
    for scen in SCENARIOS:
        # collect per-seed traces indexed by task-arrival order (0..~259)
        all_traces = []
        for seed in range(N_SEEDS):
            r = run_episode("tgpr", scen, N_ROBOTS, seed=seed + 7000, trace=True, degraded_fraction=0.22)
            all_traces.append(r["trace"])
        min_len = min(len(t) for t in all_traces)
        arr = np.array([t[:min_len] for t in all_traces])  # (seeds, tasks, 5)
        mean_over_seeds = arr.mean(axis=0)  # (tasks, 5)
        std_over_seeds = arr.std(axis=0)
        results[scen] = dict(
            task_index=list(range(min_len)),
            mean_p_hat_healthy=mean_over_seeds[:, 1].tolist(),
            mean_p_hat_degraded=mean_over_seeds[:, 2].tolist(),
            mean_timeout_healthy=mean_over_seeds[:, 3].tolist(),
            mean_timeout_degraded=mean_over_seeds[:, 4].tolist(),
            std_p_hat_healthy=std_over_seeds[:, 1].tolist(),
            std_p_hat_degraded=std_over_seeds[:, 2].tolist(),
            std_timeout_healthy=std_over_seeds[:, 3].tolist(),
            std_timeout_degraded=std_over_seeds[:, 4].tolist(),
            n_seeds=N_SEEDS,
        )
        print(f"done {scen}: {min_len} task-arrival points from {N_SEEDS} seeds", flush=True)

    with open(OUT_PATH, "w") as f:
        json.dump(results, f)
    print("TRUST TRACE DONE", flush=True)


if __name__ == "__main__":
    main()
