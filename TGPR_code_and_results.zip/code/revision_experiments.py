import csv
import time
from simulate import run_episode

FIELDNAMES = ["experiment", "variant", "protocol", "scenario", "n_robots", "degraded_fraction",
              "seed", "total_tasks", "completed", "expired", "completion_rate",
              "starvation_rate", "duplicate_rate", "mean_latency", "total_messages",
              "msgs_per_completed", "duplicate_count", "msgs_per_arrived", "duplicate_rate_arrived"]

OUT_PATH = "/home/claude/tgpr/data/revision_experiments.csv"


def row_from(r, experiment, variant, **overrides):
    total = r["total_tasks"]
    completed = r["completed"]
    dup_count = round(r["duplicate_rate"] * completed) if completed else 0
    d = dict(
        experiment=experiment, variant=variant, protocol=r["protocol"], scenario=r["scenario"],
        n_robots=r["n_robots"], degraded_fraction=overrides.get("degraded_fraction", ""),
        seed=r["seed"], total_tasks=total, completed=completed, expired=r["expired"],
        completion_rate=r["completion_rate"], starvation_rate=r["starvation_rate"],
        duplicate_rate=r["duplicate_rate"], mean_latency=r["mean_latency"],
        total_messages=r["total_messages"], msgs_per_completed=r["msgs_per_completed"],
        duplicate_count=dup_count,
        msgs_per_arrived=r["total_messages"] / total if total else float("nan"),
        duplicate_rate_arrived=dup_count / total if total else float("nan"),
    )
    return d


def main():
    t0 = time.time()
    with open(OUT_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()

        # ---------------- Experiment A: component ablation (2^3 factorial) ----------------
        N_SEEDS_A = 60
        combos = [(t, a, b) for t in (False, True) for a in (False, True) for b in (False, True)]
        for scen in ["moderate", "severe"]:
            for (ut, ua, ub) in combos:
                variant = f"T{int(ut)}A{int(ua)}B{int(ub)}"
                for seed in range(N_SEEDS_A):
                    r = run_episode("tgpr", scen, 20, seed=seed + 20000, degraded_fraction=0.22,
                                     use_trust_rank=ut, use_adaptive_timeout=ua, use_bystander=ub)
                    writer.writerow(row_from(r, "component_ablation", variant, degraded_fraction=0.22))
            f.flush()
            print(f"[A] done scenario={scen} ({time.time()-t0:.0f}s)", flush=True)

        # ---------------- Experiment B: directional trust ----------------
        N_SEEDS_B = 100
        for scen in ["poor", "severe"]:
            for seed in range(N_SEEDS_B):
                r_comb = run_episode("tgpr", scen, 20, seed=seed + 21000, degraded_fraction=0.22)
                writer.writerow(row_from(r_comb, "directional_trust", "combined", degraded_fraction=0.22))
                r_dir = run_episode("tgpr", scen, 20, seed=seed + 21000, degraded_fraction=0.22,
                                     directional_trust=True)
                writer.writerow(row_from(r_dir, "directional_trust", "directional", degraded_fraction=0.22))
            f.flush()
            print(f"[B] done scenario={scen} ({time.time()-t0:.0f}s)", flush=True)

        # ---------------- Experiment C: mechanism alternatives (Thompson / variance-recovery) ----------------
        N_SEEDS_C = 100
        for scen in ["poor", "severe"]:
            for seed in range(N_SEEDS_C):
                r_def = run_episode("tgpr", scen, 20, seed=seed + 22000, degraded_fraction=0.22)
                writer.writerow(row_from(r_def, "mechanism_alt", "default", degraded_fraction=0.22))
                r_th = run_episode("tgpr", scen, 20, seed=seed + 22000, degraded_fraction=0.22,
                                    trust_kwargs={"thompson": True})
                writer.writerow(row_from(r_th, "mechanism_alt", "thompson", degraded_fraction=0.22))
                r_vr = run_episode("tgpr", scen, 20, seed=seed + 22000, degraded_fraction=0.22,
                                    trust_kwargs={"variance_recovery": 0.05})
                writer.writerow(row_from(r_vr, "mechanism_alt", "variance_recovery", degraded_fraction=0.22))
                r_both = run_episode("tgpr", scen, 20, seed=seed + 22000, degraded_fraction=0.22,
                                      trust_kwargs={"thompson": True, "variance_recovery": 0.05})
                writer.writerow(row_from(r_both, "mechanism_alt", "thompson_and_recovery", degraded_fraction=0.22))
            f.flush()
            print(f"[C] done scenario={scen} ({time.time()-t0:.0f}s)", flush=True)

        # ---------------- Experiment D: CBBA baseline across main-sweep conditions ----------------
        N_SEEDS_D = 70
        for scen in ["excellent", "good", "moderate", "poor", "severe"]:
            for n_robots in [15, 25]:
                for seed in range(N_SEEDS_D):
                    r_cbba = run_episode("cbba", scen, n_robots, seed=seed + 23000)
                    writer.writerow(row_from(r_cbba, "cbba_baseline", "cbba", degraded_fraction=""))
                    r_tgpr = run_episode("tgpr", scen, n_robots, seed=seed + 23000)
                    writer.writerow(row_from(r_tgpr, "cbba_baseline", "tgpr", degraded_fraction=""))
                    r_naive = run_episode("naive", scen, n_robots, seed=seed + 23000)
                    writer.writerow(row_from(r_naive, "cbba_baseline", "naive", degraded_fraction=""))
            f.flush()
            print(f"[D] done scenario={scen} ({time.time()-t0:.0f}s)", flush=True)

        # ---------------- Experiment E: joint degraded-fraction x channel heatmap ----------------
        N_SEEDS_E = 50
        for scen in ["good", "moderate", "severe"]:
            for dfrac in [0.0, 0.22, 0.5]:
                for proto in ["naive", "backoff", "periodic", "tgpr"]:
                    for seed in range(N_SEEDS_E):
                        r = run_episode(proto, scen, 20, seed=seed + 24000, degraded_fraction=dfrac)
                        writer.writerow(row_from(r, "joint_heatmap", proto, degraded_fraction=dfrac))
            f.flush()
            print(f"[E] done scenario={scen} ({time.time()-t0:.0f}s)", flush=True)

    print(f"ALL REVISION EXPERIMENTS DONE in {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
