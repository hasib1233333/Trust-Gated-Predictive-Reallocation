import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 14, "axes.labelsize": 14, "axes.titlesize": 15,
    "legend.fontsize": 12, "xtick.labelsize": 12, "ytick.labelsize": 12,
    "lines.linewidth": 2.5, "lines.markersize": 8,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 1.2, "figure.dpi": 300,
})

with open("/home/claude/tgpr/data/trust_trace.json") as f:
    data = json.load(f)

fig, axes = plt.subplots(2, 2, figsize=(9.5, 7.0), sharex="col")
for col, scen in enumerate(["moderate", "severe"]):
    d = data[scen]
    x = d["task_index"]
    n = d["n_seeds"]

    ax = axes[0, col]
    mh = np.array(d["mean_p_hat_healthy"]); sh = np.array(d["std_p_hat_healthy"]) / np.sqrt(n)
    md = np.array(d["mean_p_hat_degraded"]); sd = np.array(d["std_p_hat_degraded"]) / np.sqrt(n)
    ax.plot(x, mh, label="Healthy robots", color="#4C72B0")
    ax.fill_between(x, mh - 1.96 * sh, mh + 1.96 * sh, color="#4C72B0", alpha=0.2)
    ax.plot(x, md, label="Degraded robots", color="#C44E52")
    ax.fill_between(x, md - 1.96 * sd, md + 1.96 * sd, color="#C44E52", alpha=0.2)
    ax.set_title(f"{scen.capitalize()} channel")
    ax.set_ylabel("Learned trust $\\hat p_i$" if col == 0 else "")
    if col == 0:
        ax.legend(frameon=True, framealpha=0.9, edgecolor="0.85", fontsize=12)

    ax = axes[1, col]
    th = np.array(d["mean_timeout_healthy"]); sth = np.array(d["std_timeout_healthy"]) / np.sqrt(n)
    td = np.array(d["mean_timeout_degraded"]); std_ = np.array(d["std_timeout_degraded"]) / np.sqrt(n)
    ax.plot(x, th, label="Healthy robots", color="#4C72B0")
    ax.fill_between(x, th - 1.96 * sth, th + 1.96 * sth, color="#4C72B0", alpha=0.2)
    ax.plot(x, td, label="Degraded robots", color="#C44E52")
    ax.fill_between(x, td - 1.96 * std_, td + 1.96 * std_, color="#C44E52", alpha=0.2)
    ax.axhline(25, color="gray", linestyle="--", linewidth=1)
    ax.text(x[-1], 25, " cap", fontsize=8, color="gray", va="bottom", ha="right")
    ax.set_xlabel("Task arrival index (mission progress)")
    ax.set_ylabel("Adaptive timeout $\\tau_i$ (ticks)" if col == 0 else "")

fig.suptitle("Trust and adaptive-timeout evolution over the mission (mean $\\pm$ 95% CI, 40 seeds)", y=1.0)
fig.tight_layout()
fig.savefig("/home/claude/tgpr/figures/fig_trust_evolution.png", bbox_inches="tight")
fig.savefig("/home/claude/tgpr/manuscript/build/figures/fig_trust_evolution.png", bbox_inches="tight")
print("saved")
