import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 14, "axes.labelsize": 14, "axes.titlesize": 15,
    "legend.fontsize": 12, "xtick.labelsize": 12, "ytick.labelsize": 12,
    "lines.linewidth": 2.5, "lines.markersize": 8,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 1.2, "figure.dpi": 300,
})

PROTO_LABELS = {"naive": "NaiveCNP", "backoff": "BackoffCNP", "periodic": "PeriodicRecon", "tgpr": "TGPR"}
PROTO_COLORS = {"naive": "#888888", "backoff": "#4C72B0", "periodic": "#DD8452", "tgpr": "#C44E52"}
PROTO_ORDER = ["naive", "backoff", "periodic", "tgpr"]
SCEN_ORDER = ["excellent", "good", "moderate", "poor", "severe"]

df = pd.read_csv("/home/claude/tgpr/data/main_sweep.csv")
FIGDIR = "/home/claude/tgpr/figures"


def fig_metric_by_scenario(metric, ylabel, fname, logy=False):
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 4.0), sharey=True)
    for ax, n_robots in zip(axes, sorted(df.n_robots.unique())):
        sub = df[df.n_robots == n_robots]
        for proto in PROTO_ORDER:
            means, errs = [], []
            for scen in SCEN_ORDER:
                vals = sub[(sub.protocol == proto) & (sub.scenario == scen)][metric].dropna()
                means.append(vals.mean())
                errs.append(1.96 * vals.std() / np.sqrt(len(vals)) if len(vals) > 0 else 0)
            ax.errorbar(range(len(SCEN_ORDER)), means, yerr=errs, marker="o", markersize=7,
                        label=PROTO_LABELS[proto], color=PROTO_COLORS[proto], capsize=5, linewidth=2.5, elinewidth=1.8)
        ax.set_xticks(range(len(SCEN_ORDER)))
        ax.set_xticklabels([s.capitalize() for s in SCEN_ORDER], rotation=20)
        ax.set_title(f"N = {n_robots} robots")
        if logy:
            ax.set_yscale("log")
    axes[0].set_ylabel(ylabel)
    axes[0].legend(frameon=True, framealpha=0.9, edgecolor="0.85", fontsize=12, loc="best")
    fig.suptitle(ylabel + " across channel-quality scenarios", y=1.02)
    fig.tight_layout()
    fig.savefig(f"{FIGDIR}/{fname}", bbox_inches="tight")
    plt.close(fig)


def fig_ablation():
    abl = pd.read_csv("/home/claude/tgpr/data/ablation_degraded_fraction.csv")
    fig, ax = plt.subplots(figsize=(5.5, 4.2))
    fracs = sorted(abl.degraded_fraction.unique())
    for proto in PROTO_ORDER:
        means, errs = [], []
        for f in fracs:
            vals = abl[(abl.protocol == proto) & (abl.degraded_fraction == f)].completion_rate.dropna()
            means.append(vals.mean())
            errs.append(1.96 * vals.std() / np.sqrt(len(vals)) if len(vals) > 0 else 0)
        ax.errorbar(fracs, means, yerr=errs, marker="o", markersize=7, label=PROTO_LABELS[proto],
                    color=PROTO_COLORS[proto], capsize=5, linewidth=2.5, elinewidth=1.8)
    ax.set_xlabel("Fraction of hardware-degraded robots")
    ax.set_ylabel("Completion rate")
    ax.set_title("Completion rate vs. hardware-degraded fraction\n(moderate channel, N=20)")
    ax.legend(frameon=True, framealpha=0.9, edgecolor="0.85", fontsize=12)
    fig.tight_layout()
    fig.savefig(f"{FIGDIR}/fig_ablation_degraded_fraction.png", bbox_inches="tight")
    plt.close(fig)


def fig_learning_curve():
    fig, axes = plt.subplots(1, 2, figsize=(9, 4.0), sharey=True)
    for ax, scen in zip(axes, ["moderate", "severe"]):
        sub = df[(df.scenario == scen)]
        x = np.arange(len(PROTO_ORDER))
        early = [sub[sub.protocol == p].early_completion_rate.mean() for p in PROTO_ORDER]
        late = [sub[sub.protocol == p].late_completion_rate.mean() for p in PROTO_ORDER]
        width = 0.35
        ax.bar(x - width / 2, early, width, label="Early half", color="#9ecae1")
        ax.bar(x + width / 2, late, width, label="Late half", color="#3182bd")
        ax.set_xticks(x)
        ax.set_xticklabels([PROTO_LABELS[p] for p in PROTO_ORDER], rotation=20)
        ax.set_title(f"{scen.capitalize()} channel")
    axes[0].set_ylabel("Completion rate")
    axes[0].legend(frameon=True, framealpha=0.9, edgecolor="0.85", fontsize=12)
    fig.suptitle("Early- vs. late-mission completion rate (trust warm-up effect)", y=1.02)
    fig.tight_layout()
    fig.savefig(f"{FIGDIR}/fig_learning_curve.png", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    fig_metric_by_scenario("completion_rate", "Completion rate", "fig_completion_rate.png")
    fig_metric_by_scenario("duplicate_rate", "Duplicate-execution rate", "fig_duplicate_rate.png")
    fig_metric_by_scenario("msgs_per_completed", "Messages per completed task", "fig_msgs_per_completed.png", logy=True)
    fig_metric_by_scenario("mean_latency", "Mean allocation latency (ticks)", "fig_latency.png")
    fig_ablation()
    fig_learning_curve()
    print("all figures written")
