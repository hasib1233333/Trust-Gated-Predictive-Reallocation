import csv
import time
from simulate import run_episode

REMAINING = [
    ("good", 25), ("moderate", 15), ("moderate", 25),
    ("poor", 15), ("poor", 25), ("severe", 15), ("severe", 25),
]
PROTOCOLS = ["naive", "backoff", "periodic", "tgpr"]
N_SEEDS = 120
OUT_PATH = "/home/claude/tgpr/data/main_sweep.csv"

FIELDNAMES = ["protocol", "scenario", "n_robots", "seed", "total_tasks", "completed",
              "expired", "completion_rate", "starvation_rate", "duplicate_rate",
              "mean_latency", "median_latency", "total_messages", "msgs_per_completed",
              "wasted_exec_ticks", "episode_ticks", "early_completion_rate", "late_completion_rate"]


def main():
    t0 = time.time()
    n_done = 0
    n_total = len(REMAINING) * N_SEEDS * len(PROTOCOLS)
    with open(OUT_PATH, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        for scen, n_robots in REMAINING:
            for seed in range(N_SEEDS):
                for proto in PROTOCOLS:
                    r = run_episode(proto, scen, n_robots, seed=seed + 5000)
                    row = {k: r[k] for k in FIELDNAMES}
                    writer.writerow(row)
                    n_done += 1
            f.flush()
            elapsed = time.time() - t0
            print(f"done scenario={scen} n_robots={n_robots}  "
                  f"({n_done}/{n_total}, {elapsed:.0f}s elapsed)", flush=True)
    print(f"RESUME DONE in {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
