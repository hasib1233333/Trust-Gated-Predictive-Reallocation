import csv
import time
from simulate import run_episode

PROTOCOLS = ["naive", "backoff", "periodic", "tgpr"]
N_SEEDS = 100
SCENARIO = "moderate"
N_ROBOTS = 20
OUT_PATH = "/home/claude/tgpr/data/ablation_degraded_fraction.csv"

FIELDNAMES = ["protocol", "degraded_fraction", "seed", "total_tasks", "completed",
              "expired", "completion_rate", "starvation_rate", "duplicate_rate",
              "mean_latency", "msgs_per_completed", "early_completion_rate",
              "late_completion_rate"]


def main():
    t0 = time.time()
    with open(OUT_PATH, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        # finish remaining seeds for fraction 0.22 (seeds 51..99, one overlap accepted)
        for seed in range(51, N_SEEDS):
            for proto in PROTOCOLS:
                r = run_episode(proto, SCENARIO, N_ROBOTS, seed=seed + 9000, degraded_fraction=0.22)
                r["degraded_fraction"] = 0.22
                writer.writerow({k: r[k] for k in FIELDNAMES})
        f.flush()
        print(f"done degraded_fraction=0.22 remainder ({time.time()-t0:.0f}s elapsed)", flush=True)

        for dfrac in [0.35, 0.5]:
            for seed in range(N_SEEDS):
                for proto in PROTOCOLS:
                    r = run_episode(proto, SCENARIO, N_ROBOTS, seed=seed + 9000, degraded_fraction=dfrac)
                    r["degraded_fraction"] = dfrac
                    writer.writerow({k: r[k] for k in FIELDNAMES})
            f.flush()
            print(f"done degraded_fraction={dfrac} ({time.time()-t0:.0f}s elapsed)", flush=True)
    print(f"ABLATION RESUME DONE in {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
