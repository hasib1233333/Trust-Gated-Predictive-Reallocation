"""
TGPR simulation engine.

Star-topology multi-robot task allocation testbed: a base station (auctioneer)
coordinates N heterogeneous robots over a lossy, distance- and interference-
dependent wireless channel. Tasks arrive stochastically; the base runs an
auction (announce -> bid -> award -> ack) to assign each task to a robot.

This module is protocol-agnostic: it implements the world, channel, and task
life-cycle bookkeeping. Allocation *policy* (winner selection, timeout sizing,
reallocation behavior, unsolicited-claim behavior) is injected via a Protocol
object (see protocols.py) so that all compared methods run through identical
world dynamics and differ only in decision logic.
"""

import heapq
import math
import numpy as np

FIELD_SIZE = 120.0
COMM_RANGE = 100.0   # corner-to-center distance is ~84.9, so the whole field is in range,
                     # with reliability smoothly decaying by distance rather than a hard cutoff
ROBOT_SPEED = 1.6
SERVICE_TIME = 6
CAP_DIM = 3

# --- Message types ---
MSG_ANNOUNCE = "announce"
MSG_BID = "bid"
MSG_AWARD = "award"
MSG_ACK = "ack"
MSG_CANCEL = "cancel"
MSG_CONFIRM_BCAST = "confirm_bcast"   # base -> all: task X confirmed to robot i
MSG_UNSOLICITED_BID = "unsolicited_bid"


CHANNEL_SCENARIOS = {
    "excellent": dict(base_reliability=0.98, jam_prob=0.002, jam_severity=0.75, jam_dur_mean=5),
    "good":      dict(base_reliability=0.92, jam_prob=0.006, jam_severity=0.55, jam_dur_mean=8),
    "moderate":  dict(base_reliability=0.82, jam_prob=0.012, jam_severity=0.38, jam_dur_mean=12),
    "poor":      dict(base_reliability=0.68, jam_prob=0.022, jam_severity=0.25, jam_dur_mean=16),
    "severe":    dict(base_reliability=0.50, jam_prob=0.035, jam_severity=0.15, jam_dur_mean=20),
}

UPLINK_ASYMMETRY = 0.85   # robot->base transmitters are weaker than base->robot
DECAY_RATE = 1.15
MAX_EXTRA_DELAY = 3.0
CONGESTION_BURST_PROB = 0.05
CONGESTION_BURST_MEAN = 3.0


class Channel:
    """Distance- and interference-dependent lossy channel to a central base,
    plus persistent per-robot hardware reliability (antenna/radio quality)
    that is independent of position and does not decay or move."""

    def __init__(self, scenario, n_robots, rng, reliability_factors=None):
        self.p = CHANNEL_SCENARIOS[scenario]
        self.rng = rng
        self.jam_mult = np.ones(n_robots)
        self.jam_remaining = np.zeros(n_robots, dtype=int)
        if reliability_factors is None:
            reliability_factors = np.ones(n_robots)
        self.reliability_factors = reliability_factors

    def step_jamming(self):
        p = self.p
        for i in range(len(self.jam_mult)):
            if self.jam_remaining[i] > 0:
                self.jam_remaining[i] -= 1
                if self.jam_remaining[i] == 0:
                    self.jam_mult[i] = 1.0
            elif self.rng.random() < p["jam_prob"]:
                self.jam_mult[i] = p["jam_severity"]
                dur = max(1, self.rng.poisson(p["jam_dur_mean"]))
                self.jam_remaining[i] = dur

    def _base_p(self, dist, robot_idx):
        if dist > COMM_RANGE:
            return 0.0
        p = self.p["base_reliability"] * math.exp(-DECAY_RATE * dist / COMM_RANGE)
        p *= self.jam_mult[robot_idx]
        p *= self.reliability_factors[robot_idx]
        return float(np.clip(p, 0.01, 0.99))

    def transmit(self, dist, robot_idx, direction):
        """Return (delivered: bool, delay_ticks: int). direction in {'up','down'}."""
        p_succ = self._base_p(dist, robot_idx)
        if direction == "up":
            p_succ *= UPLINK_ASYMMETRY
        delivered = self.rng.random() < p_succ
        extra = self.rng.poisson(max(0.0, (dist / COMM_RANGE) * MAX_EXTRA_DELAY))
        if self.rng.random() < CONGESTION_BURST_PROB:
            extra += self.rng.geometric(1.0 / CONGESTION_BURST_MEAN)
        delay = max(1, 1 + int(extra))
        return delivered, delay, p_succ


class Robot:
    __slots__ = ["idx", "pos", "capability", "assigned_task", "state", "target", "reliability_factor"]

    def __init__(self, idx, pos, capability, reliability_factor=1.0):
        self.idx = idx
        self.pos = np.array(pos, dtype=float)
        self.capability = capability
        self.assigned_task = None    # task id currently confirmed/executing, or None
        self.state = "idle"          # idle | committed (awaiting ack ack'd) | executing
        self.target = None
        self.reliability_factor = reliability_factor

    def dist_to_base(self, base_pos):
        return float(np.linalg.norm(self.pos - base_pos))

    def dist_to(self, point):
        return float(np.linalg.norm(self.pos - point))


class Task:
    __slots__ = ["tid", "loc", "req", "created", "deadline", "status", "holder",
                 "bids", "bid_window_end", "ack_deadline", "reassign_attempts",
                 "announce_rounds", "confirmed_tick", "completed_tick", "duplicate",
                 "extra"]

    def __init__(self, tid, loc, req, created, deadline):
        self.tid = tid
        self.loc = loc
        self.req = req
        self.created = created
        self.deadline = deadline
        self.status = "awaiting_bids"     # awaiting_bids|awaiting_ack|confirmed|completed|expired
        self.holder = None
        self.bids = {}                    # robot_idx -> (utility, p_up_at_send)
        self.bid_window_end = None
        self.ack_deadline = None
        self.reassign_attempts = 0
        self.announce_rounds = 0
        self.confirmed_tick = None
        self.completed_tick = None
        self.duplicate = False
        self.extra = {}


def capability_match(cap, req):
    d = np.linalg.norm(cap - req)
    dmax = math.sqrt(CAP_DIM) * 1.6
    return float(np.clip(1.0 - d / dmax, 0.0, 1.0))


def utility(robot, task):
    cm = capability_match(robot.capability, task.req)
    dist = robot.dist_to(task.loc)
    prox = 1.0 / (1.0 + dist / COMM_RANGE)
    return cm * prox


DEGRADED_UNIT_FRACTION = 0.22
DEGRADED_RELIABILITY_RANGE = (0.35, 0.62)
HEALTHY_RELIABILITY_RANGE = (0.85, 1.0)


def make_robot_population(n, rng, degraded_fraction=DEGRADED_UNIT_FRACTION):
    types = rng.integers(0, 3, size=n)
    is_degraded = rng.random(n) < degraded_fraction
    robots = []
    for i in range(n):
        base_profile = np.array([
            [1.0, 0.3, 0.3],
            [0.3, 1.0, 0.4],
            [0.4, 0.3, 1.0],
        ])[types[i]]
        cap = np.clip(base_profile + rng.normal(0, 0.12, size=CAP_DIM), 0, 1.3)
        pos = rng.uniform(0, FIELD_SIZE, size=2)
        if is_degraded[i]:
            rel = rng.uniform(*DEGRADED_RELIABILITY_RANGE)
        else:
            rel = rng.uniform(*HEALTHY_RELIABILITY_RANGE)
        robots.append(Robot(i, pos, cap, reliability_factor=rel))
    return robots
