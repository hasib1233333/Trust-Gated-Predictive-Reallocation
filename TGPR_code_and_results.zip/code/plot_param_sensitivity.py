import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 14, "axes.labelsize": 14, "axes.titlesize": 15,
    "legend.fontsize": 12, "xtick.labelsize": 12, "ytick.labelsize": 12,
    "lines.linewidth": 2.5, "lines.markersize": 8,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 1.2, "figure.dpi": 300,
})

df = pd.read_csv("/home/claude/tgpr/data/param_sensitivity.csv")
FIGDIRS = ["/home/claude/tgpr/figures", "/home/claude/tgpr/manuscript/build/figures"]

fig, axes = plt.subplots(1, 2, figsize=(9.5, 4.0))

zsub = df[df.sweep == "z"]
zvals = sorted(zsub.value.unique())
ax = axes[0]
comp = [zsub[zsub.value == z].completion_rate.mean() for z in zvals]
comp_se = [1.96 * zsub[zsub.value == z].completion_rate.std() / np.sqrt((zsub.value == z).sum()) for z in zvals]
dup = [zsub[zsub.value == z].duplicate_rate.mean() for z in zvals]
dup_se = [1.96 * zsub[zsub.value == z].duplicate_rate.std() / np.sqrt((zsub.value == z).sum()) for z in zvals]
ax2 = ax.twinx()
l1 = ax.errorbar(zvals, comp, yerr=comp_se, marker="o", color="#4C72B0", label="Completion rate")
l2 = ax2.errorbar(zvals, dup, yerr=dup_se, marker="s", color="#C44E52", label="Duplicate rate")
ax.axvline(1.8, color="gray", linestyle="--", linewidth=1)
ax.text(1.8, ax.get_ylim()[1], " default", fontsize=8, color="gray", va="top")
ax.set_xlabel("Timeout multiplier $z$")
ax.set_ylabel("Completion rate", color="#4C72B0")
ax2.set_ylabel("Duplicate rate", color="#C44E52")
ax.set_title("Severe channel, $N=20$")
lines = [l1, l2]
ax.legend(lines, [l.get_label() for l in lines], frameon=True, framealpha=0.9, edgecolor="0.85", fontsize=12, loc="center left")

dsub = df[df.sweep == "decay"]
dvals = sorted(dsub.value.unique())
ax = axes[1]
comp = [dsub[dsub.value == d].completion_rate.mean() for d in dvals]
comp_se = [1.96 * dsub[dsub.value == d].completion_rate.std() / np.sqrt((dsub.value == d).sum()) for d in dvals]
dup = [dsub[dsub.value == d].duplicate_rate.mean() for d in dvals]
dup_se = [1.96 * dsub[dsub.value == d].duplicate_rate.std() / np.sqrt((dsub.value == d).sum()) for d in dvals]
ax2 = ax.twinx()
l1 = ax.errorbar(dvals, comp, yerr=comp_se, marker="o", color="#4C72B0", label="Completion rate")
l2 = ax2.errorbar(dvals, dup, yerr=dup_se, marker="s", color="#C44E52", label="Duplicate rate")
ax.axvline(0.97, color="gray", linestyle="--", linewidth=1)
ax.text(0.97, ax.get_ylim()[1], " default", fontsize=8, color="gray", va="top")
ax.set_xlabel("Trust decay factor $\\lambda$")
ax.set_ylabel("Completion rate", color="#4C72B0")
ax2.set_ylabel("Duplicate rate", color="#C44E52")
ax.set_title("Severe channel, $N=20$")

fig.suptitle("TGPR hyperparameter sensitivity (mean $\\pm$ 95% CI, 60 seeds/value)", y=1.03)
fig.tight_layout()
for d in FIGDIRS:
    fig.savefig(f"{d}/fig_param_sensitivity.png", bbox_inches="tight")
print("saved")
