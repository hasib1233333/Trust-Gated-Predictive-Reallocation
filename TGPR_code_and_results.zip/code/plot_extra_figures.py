import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 14, "axes.labelsize": 14, "axes.titlesize": 15,
    "legend.fontsize": 12, "xtick.labelsize": 12, "ytick.labelsize": 12,
    "lines.linewidth": 2.5, "lines.markersize": 8,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 1.2, "figure.dpi": 300,
})

FIGDIRS = ["/home/claude/tgpr/figures", "/home/claude/tgpr/manuscript/build/figures"]
PROTO_LABELS = {"naive": "NaiveCNP", "backoff": "BackoffCNP", "periodic": "PeriodicRecon", "tgpr": "TGPR"}
PROTO_ORDER = ["naive", "backoff", "periodic", "tgpr"]
SCEN_ORDER = ["excellent", "good", "moderate", "poor", "severe"]


def save(fig, name):
    for d in FIGDIRS:
        fig.savefig(f"{d}/{name}", bbox_inches="tight")


# ---------- significance heatmap ----------
sig = pd.read_csv("/home/claude/tgpr/data/significance_tests.csv")
sig25 = sig[sig.n_robots == 25].copy()
metrics = ["completion_rate", "duplicate_rate", "msgs_per_completed"]
metric_labels = {"completion_rate": "Completion\nrate", "duplicate_rate": "Duplicate\nrate",
                  "msgs_per_completed": "Messages/\ntask"}
baselines = ["naive", "backoff", "periodic"]

fig, axes = plt.subplots(1, 3, figsize=(11, 4.2), sharey=True)
for ax, metric in zip(axes, metrics):
    grid = np.zeros((len(SCEN_ORDER), len(baselines)))
    annot = np.empty((len(SCEN_ORDER), len(baselines)), dtype=object)
    for i, scen in enumerate(SCEN_ORDER):
        for j, base in enumerate(baselines):
            row = sig25[(sig25.scenario == scen) & (sig25.baseline == base) & (sig25.metric == metric)]
            if len(row) == 0:
                grid[i, j] = 0
                annot[i, j] = ""
                continue
            r = row.iloc[0]
            eff = r.rank_biserial
            # sign convention: positive = TGPR better (lower for duplicate/msgs, higher for completion)
            if metric == "completion_rate":
                better = eff > 0
            else:
                better = eff < 0
            direction = 1 if better else -1
            sig_flag = r.p_value < 0.05
            grid[i, j] = direction * abs(eff) * (1 if sig_flag else 0.15)
            star = "*" if sig_flag else ""
            annot[i, j] = f"{r.p_value:.3f}{star}"
    im = ax.imshow(grid, cmap="RdYlGn", vmin=-0.8, vmax=0.8, aspect="auto")
    ax.set_xticks(range(len(baselines)))
    ax.set_xticklabels([PROTO_LABELS[b] for b in baselines], rotation=30, ha="right", fontsize=9)
    ax.set_yticks(range(len(SCEN_ORDER)))
    ax.set_yticklabels([s.capitalize() for s in SCEN_ORDER])
    ax.set_title(metric_labels[metric], fontsize=10)
    for i in range(len(SCEN_ORDER)):
        for j in range(len(baselines)):
            ax.text(j, i, annot[i, j], ha="center", va="center", fontsize=7.5)
fig.suptitle("TGPR vs.\ baselines: effect direction (green=TGPR better) and $p$-value ($N{=}25$; * = $p{<}0.05$)", y=1.03, fontsize=11)
fig.tight_layout()
save(fig, "fig_significance_heatmap.png")
plt.close(fig)

# ---------- latency distribution (per-trial mean latency across seeds) ----------
df = pd.read_csv("/home/claude/tgpr/data/main_sweep.csv")
fig, axes = plt.subplots(1, 2, figsize=(9.5, 4.2), sharey=True)
for ax, n_robots in zip(axes, [15, 25]):
    box_data = []
    labels = []
    colors = []
    color_map = {"naive": "#888888", "backoff": "#4C72B0", "periodic": "#DD8452", "tgpr": "#C44E52"}
    for scen in SCEN_ORDER:
        for p in PROTO_ORDER:
            vals = df[(df.scenario == scen) & (df.n_robots == n_robots) & (df.protocol == p)].mean_latency.dropna()
            box_data.append(vals)
            labels.append(f"{scen[:3].upper()}\n{PROTO_LABELS[p][:4]}")
            colors.append(color_map[p])
    bp = ax.boxplot(box_data, patch_artist=True, showfliers=False, widths=0.6)
    for patch, c in zip(bp["boxes"], colors):
        patch.set_facecolor(c)
        patch.set_alpha(0.7)
    ax.set_xticks([])
    ax.set_title(f"N = {n_robots} robots")
    # add scenario group labels
    for k, scen in enumerate(SCEN_ORDER):
        ax.text(k * 4 + 2.5, ax.get_ylim()[0], scen.capitalize(), ha="center", va="top", fontsize=8, rotation=0)
axes[0].set_ylabel("Per-trial mean allocation latency (ticks)")
from matplotlib.patches import Patch
legend_elems = [Patch(facecolor=c, alpha=0.7, label=PROTO_LABELS[p]) for p, c in color_map.items()]
axes[1].legend(handles=legend_elems, frameon=True, framealpha=0.9, edgecolor="0.85", fontsize=12, loc="upper left")
fig.suptitle("Distribution of per-trial mean allocation latency across seeds", y=1.02)
fig.tight_layout()
save(fig, "fig_latency_boxplot.png")
plt.close(fig)

# ---------- radar summary ----------
overall = df.groupby("protocol")[["completion_rate", "duplicate_rate", "msgs_per_completed"]].mean()
# normalize each metric to [0,1] where 1 = best across protocols, for visual comparability
norm = pd.DataFrame(index=overall.index)
norm["Completion"] = (overall.completion_rate - overall.completion_rate.min()) / (overall.completion_rate.max() - overall.completion_rate.min() + 1e-9)
norm["Low duplication"] = 1 - (overall.duplicate_rate - overall.duplicate_rate.min()) / (overall.duplicate_rate.max() - overall.duplicate_rate.min() + 1e-9)
norm["Low messaging"] = 1 - (overall.msgs_per_completed - overall.msgs_per_completed.min()) / (overall.msgs_per_completed.max() - overall.msgs_per_completed.min() + 1e-9)
cats = list(norm.columns)
angles = np.linspace(0, 2 * np.pi, len(cats), endpoint=False).tolist()
angles += angles[:1]

fig, ax = plt.subplots(figsize=(5.5, 5.5), subplot_kw=dict(polar=True))
color_map = {"naive": "#888888", "backoff": "#4C72B0", "periodic": "#DD8452", "tgpr": "#C44E52"}
for p in PROTO_ORDER:
    vals = norm.loc[p].tolist()
    vals += vals[:1]
    ax.plot(angles, vals, label=PROTO_LABELS[p], color=color_map[p], linewidth=2)
    ax.fill(angles, vals, color=color_map[p], alpha=0.08)
ax.set_xticks(angles[:-1])
ax.set_xticklabels(cats, fontsize=10)
ax.set_yticks([0.25, 0.5, 0.75, 1.0])
ax.set_yticklabels(["0.25", "0.50", "0.75", "1.0"], fontsize=7)
ax.set_title("Normalized aggregate performance\n(1.0 = best protocol on that axis)", y=1.08)
ax.legend(loc="upper right", bbox_to_anchor=(1.3, 1.1), frameon=True, framealpha=0.9, edgecolor="0.85", fontsize=12)
fig.tight_layout()
save(fig, "fig_radar_summary.png")
plt.close(fig)

print("all three figures saved")
