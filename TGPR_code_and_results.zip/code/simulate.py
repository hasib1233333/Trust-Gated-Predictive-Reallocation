import numpy as np
from engine import (Channel, Task, make_robot_population, utility, capability_match,
                     FIELD_SIZE, COMM_RANGE, ROBOT_SPEED, SERVICE_TIME, CAP_DIM)

BASE_POS = np.array([FIELD_SIZE / 2, FIELD_SIZE / 2])

BID_WINDOW = 6
FIXED_ACK_TIMEOUT = 8
BACKOFF_MULT = 1.8
MAX_REASSIGN = 3
MAX_OUTBID = 3   # cap on CBBA-SI outbid cascades per task, to prevent pathological loops
MAX_REANNOUNCE = 10_000   # effectively unlimited: tasks end only via true deadline expiry
PERIODIC_SYNC = 10

TGPR_PRIOR_ALPHA = 2.0
TGPR_PRIOR_BETA = 2.0
TGPR_DECAY = 0.97
TGPR_DELAY_PRIOR_MEAN = 5.0
TGPR_DELAY_PRIOR_VAR = 4.0
TGPR_DELAY_EMA = 0.35
TGPR_Z = 1.8
TGPR_TIMEOUT_MIN = 3
TGPR_TIMEOUT_MAX = 25
FAILURE_VAR_INFLATE = 1.15   # multiplicative delay-variance inflation on each observed failure
FAILURE_VAR_ADD = 0.5        # additive delay-variance inflation on each observed failure
TGPR_BYSTANDER_GRACE = 2   # ticks bystanders get to preempt the base's own reassignment

M_TOTAL_TASKS = 260
TASK_ARRIVAL_P = 0.35
DEADLINE_TICKS = 90
MAX_TICKS = 1400


class TrustModel:
    """Per-robot Bayesian round-trip reliability + delay estimator (TGPR only).

    Variance update rule (the rule Reviewer 2 asked to see written out explicitly):
    on every observed failure, delay_var is inflated multiplicatively and by a fixed
    additive term:
        delay_var[i] <- min(timeout_max^2, delay_var[i] * FAILURE_VAR_INFLATE + FAILURE_VAR_ADD)
    which has no term pulling delay_var back toward the prior when failures stop.
    variance_recovery (default 0, i.e. the original TGPR rule) adds an optional pull-
    to-prior term applied on every update (success or failure):
        delay_var[i] <- delay_var[i] + variance_recovery * (delay_prior_var - delay_var[i])
    applied immediately after the inflation/EMA step above, tested as an alternative
    mechanism in the revision's mechanism ablation.

    thompson (default False, i.e. the original TGPR rule) switches the ranking score
    from the posterior mean p_hat to a single sample drawn from Beta(alpha_i, beta_i)
    each time rank_score is called, giving robots with fewer observations (wider
    posteriors) an occasional chance to be ranked highly even if their running mean
    is currently low -- the classical Thompson-sampling exploration mechanism,
    tested here as an alternative to the pure-exploitation ranking rule.
    """

    def __init__(self, n, prior_alpha=TGPR_PRIOR_ALPHA, prior_beta=TGPR_PRIOR_BETA,
                 decay=TGPR_DECAY, delay_prior_mean=TGPR_DELAY_PRIOR_MEAN,
                 delay_prior_var=TGPR_DELAY_PRIOR_VAR, delay_ema=TGPR_DELAY_EMA,
                 z=TGPR_Z, timeout_min=TGPR_TIMEOUT_MIN, timeout_max=TGPR_TIMEOUT_MAX,
                 variance_recovery=0.0, thompson=False, rng=None):
        self.alpha = np.full(n, prior_alpha)
        self.beta = np.full(n, prior_beta)
        self.delay_mean = np.full(n, delay_prior_mean)
        self.delay_var = np.full(n, delay_prior_var)
        self.delay_prior_var = delay_prior_var
        self.decay = decay
        self.delay_ema = delay_ema
        self.z = z
        self.timeout_min = timeout_min
        self.timeout_max = timeout_max
        self.variance_recovery = variance_recovery
        self.thompson = thompson
        self.rng = rng if rng is not None else np.random.default_rng()

    def p_hat(self, i):
        return self.alpha[i] / (self.alpha[i] + self.beta[i])

    def rank_score(self, i):
        """Score used for bid ranking: posterior mean (default) or a Thompson sample."""
        if self.thompson:
            return float(self.rng.beta(self.alpha[i], self.beta[i]))
        return self.p_hat(i)

    def timeout_for(self, i):
        std = np.sqrt(self.delay_var[i])
        t = self.delay_mean[i] + self.z * std
        return int(np.clip(round(t), self.timeout_min, self.timeout_max))

    def update_success(self, i, observed_delay):
        self.alpha[i] = self.decay * self.alpha[i] + 1.0
        self.beta[i] = self.decay * self.beta[i]
        err = observed_delay - self.delay_mean[i]
        self.delay_mean[i] += self.delay_ema * err
        self.delay_var[i] = (1 - self.delay_ema) * (self.delay_var[i] + self.delay_ema * err * err)
        if self.variance_recovery > 0:
            self.delay_var[i] += self.variance_recovery * (self.delay_prior_var - self.delay_var[i])

    def update_failure(self, i):
        self.beta[i] = self.decay * self.beta[i] + 1.0
        self.alpha[i] = self.decay * self.alpha[i]
        self.delay_var[i] = min(self.timeout_max ** 2,
                                 self.delay_var[i] * FAILURE_VAR_INFLATE + FAILURE_VAR_ADD)
        if self.variance_recovery > 0:
            self.delay_var[i] += self.variance_recovery * (self.delay_prior_var - self.delay_var[i])


class DirectionalTrustModel:
    """Variant of TrustModel that maintains separate Beta posteriors for the
    downlink (coordinator->robot, observable immediately via a MAC-layer-style
    per-hop ack) and uplink (robot->coordinator, only inferable once the downlink
    is known to have succeeded) legs of the round trip, rather than one combined
    round-trip estimator. Delay statistics (used for timeout sizing) are kept
    combined, since disentangling direction is specifically about the reliability
    estimate used for ranking and failure attribution, not about delay timing.
    Used only in the uplink/downlink ablation (Section 6.6 of the revision)."""

    def __init__(self, n, prior_alpha=TGPR_PRIOR_ALPHA, prior_beta=TGPR_PRIOR_BETA,
                 decay=TGPR_DECAY, delay_prior_mean=TGPR_DELAY_PRIOR_MEAN,
                 delay_prior_var=TGPR_DELAY_PRIOR_VAR, delay_ema=TGPR_DELAY_EMA,
                 z=TGPR_Z, timeout_min=TGPR_TIMEOUT_MIN, timeout_max=TGPR_TIMEOUT_MAX,
                 **_ignored):
        self.alpha_down = np.full(n, prior_alpha)
        self.beta_down = np.full(n, prior_beta)
        self.alpha_up = np.full(n, prior_alpha)
        self.beta_up = np.full(n, prior_beta)
        self.delay_mean = np.full(n, delay_prior_mean)
        self.delay_var = np.full(n, delay_prior_var)
        self.decay = decay
        self.delay_ema = delay_ema
        self.z = z
        self.timeout_min = timeout_min
        self.timeout_max = timeout_max

    def p_down(self, i):
        return self.alpha_down[i] / (self.alpha_down[i] + self.beta_down[i])

    def p_up(self, i):
        return self.alpha_up[i] / (self.alpha_up[i] + self.beta_up[i])

    def p_hat(self, i):
        return self.p_down(i) * self.p_up(i)

    def rank_score(self, i):
        return self.p_hat(i)

    def timeout_for(self, i):
        std = np.sqrt(self.delay_var[i])
        t = self.delay_mean[i] + self.z * std
        return int(np.clip(round(t), self.timeout_min, self.timeout_max))

    def update_down(self, i, success):
        if success:
            self.alpha_down[i] = self.decay * self.alpha_down[i] + 1.0
            self.beta_down[i] = self.decay * self.beta_down[i]
        else:
            self.beta_down[i] = self.decay * self.beta_down[i] + 1.0
            self.alpha_down[i] = self.decay * self.alpha_down[i]

    def update_up(self, i, success, observed_delay=None):
        if success:
            self.alpha_up[i] = self.decay * self.alpha_up[i] + 1.0
            self.beta_up[i] = self.decay * self.beta_up[i]
            if observed_delay is not None:
                err = observed_delay - self.delay_mean[i]
                self.delay_mean[i] += self.delay_ema * err
                self.delay_var[i] = (1 - self.delay_ema) * (self.delay_var[i] + self.delay_ema * err * err)
        else:
            self.beta_up[i] = self.decay * self.beta_up[i] + 1.0
            self.alpha_up[i] = self.decay * self.alpha_up[i]
            self.delay_var[i] = min(self.timeout_max ** 2,
                                     self.delay_var[i] * FAILURE_VAR_INFLATE + FAILURE_VAR_ADD)


def run_episode(protocol, scenario, n_robots, seed, deadline_ticks=DEADLINE_TICKS, debug=False,
                 degraded_fraction=None, trust_kwargs=None, trace=False,
                 use_trust_rank=None, use_adaptive_timeout=None, use_bystander=None,
                 directional_trust=False):
    """
    protocol in {'naive', 'backoff', 'periodic', 'tgpr', 'cbba'}
    Returns a dict of episode-level metrics. All protocols share identical
    world dynamics, channel model, and cancellation reconciliation; they differ
    only in winner-selection rule, ack-timeout sizing, reallocation cadence, and
    (TGPR only) trust learning + confidence-gated unilateral bystander claiming.

    trust_kwargs: optional dict of TrustModel constructor overrides (z, decay,
                  variance_recovery, thompson, etc.) for sensitivity analysis and
                  the mechanism-ablation variants; ignored for non-TGPR protocols.
    trace: if True (TGPR only), also returns 'trace' — a list of per-tick snapshots
           of (tick, mean_p_hat_healthy, mean_p_hat_degraded, mean_timeout_healthy,
           mean_timeout_degraded) sampled at every task arrival, for inspecting how
           trust and adaptive timeouts evolve over the mission.

    use_trust_rank / use_adaptive_timeout / use_bystander: component-ablation
    switches (TGPR only; None means "on", matching full TGPR). Setting any to
    False disables that one mechanism while leaving the other two active and the
    trust model still learning in the background, so the eight on/off combinations
    isolate each mechanism's individual contribution. When use_adaptive_timeout is
    False, TGPR falls back to the fixed NaiveCNP timeout; when use_trust_rank is
    False, bids are ranked by raw utility as in the baselines.

    directional_trust: if True (TGPR only), maintain separate uplink and downlink
    Beta estimators per robot instead of one combined round-trip estimator, and
    rank/size timeouts from their product, testing whether disentangling direction
    recovers any of the completion-rate cost attributed to one-directional faults.
    """
    use_trust_rank = True if use_trust_rank is None else use_trust_rank
    use_adaptive_timeout = True if use_adaptive_timeout is None else use_adaptive_timeout
    use_bystander = True if use_bystander is None else use_bystander
    rng = np.random.default_rng(seed)
    from engine import DEGRADED_UNIT_FRACTION
    dfrac = DEGRADED_UNIT_FRACTION if degraded_fraction is None else degraded_fraction
    robots = make_robot_population(n_robots, rng, degraded_fraction=dfrac)
    reliability_factors = np.array([r.reliability_factor for r in robots])
    channel = Channel(scenario, n_robots, rng, reliability_factors=reliability_factors)
    trust = TrustModel(n_robots, **(trust_kwargs or {})) if protocol == "tgpr" else None
    if protocol == "tgpr" and "rng" not in (trust_kwargs or {}):
        trust.rng = rng  # share the episode RNG so Thompson draws are reproducible per seed
    dtrust = DirectionalTrustModel(n_robots, **(trust_kwargs or {})) if (protocol == "tgpr" and directional_trust) else None
    is_degraded = reliability_factors < 0.7
    trace_log = [] if (trace and protocol == "tgpr") else None

    tasks = {}
    next_tid = 0
    n_arrived = 0
    duplicate_count = 0
    latencies = []
    total_msgs = 0
    wasted_exec_ticks = 0

    executors = {}              # tid -> list of {'ridx','finish_tick','status'}
    confirm_overheard = {}       # tid -> set of bystander robot idx that overheard the award+deadline
    award_broadcast_deadline = {}  # tid -> (winner_idx, deadline_tick)
    scheduled_cancels = []       # list of (arrival_tick, ridx, tid)

    dbg_pool_sizes = []
    dbg_rerank_changed = 0
    dbg_rerank_total = 0
    dbg_timeouts = []
    dbg_bystander_claims = 0
    dbg_cancels_sent = 0
    dbg_cancels_delivered = 0

    def send(dist_from_base, robot_idx, direction):
        nonlocal total_msgs
        total_msgs += 1
        delivered, delay, p = channel.transmit(dist_from_base, robot_idx, direction)
        return delivered, delay, p

    def try_cancel(ridx, tid, tick):
        nonlocal dbg_cancels_sent, dbg_cancels_delivered
        dbg_cancels_sent += 1
        r = robots[ridx]
        dist = r.dist_to_base(BASE_POS)
        delivered, delay, p = send(dist, ridx, "down")
        if delivered:
            dbg_cancels_delivered += 1
            scheduled_cancels.append((tick + delay, ridx, tid))

    def start_announce(task, tick):
        task.status = "awaiting_bids"
        task.bids = {}
        task.bid_window_end = tick + BID_WINDOW
        task.announce_rounds += 1
        cbba_seen = task.extra.setdefault("cbba_bid_from", set()) if protocol == "cbba" else None
        for r in robots:
            if r.state != "idle":
                continue
            dist = r.dist_to_base(BASE_POS)
            delivered, delay, p = send(dist, r.idx, "down")
            arrive_tick = tick + delay
            if delivered and arrive_tick <= task.bid_window_end:
                u = utility(r, task)
                if u > 0.05:
                    bdelivered, bdelay, bp = send(dist, r.idx, "up")
                    bid_arrival = arrive_tick + bdelay
                    if bdelivered and bid_arrival <= task.bid_window_end + 4:
                        task.bids.setdefault(bid_arrival, []).append((r.idx, u))
                        if cbba_seen is not None:
                            cbba_seen.add(r.idx)

    def finalize_bidding(task, tick):
        pool = []
        for arr_tick, entries in list(task.bids.items()):
            if arr_tick <= tick:
                pool.extend(entries)
        if not pool:
            start_announce(task, tick)
            return
        dbg_pool_sizes.append(len(pool))
        task.extra["pool"] = sorted(pool, key=lambda x: -x[1])
        task.extra["tried"] = set()
        award_next(task, tick, attempt=0)

    def rank_pool(task):
        pool = task.extra.get("pool", [])
        if protocol == "tgpr" and use_trust_rank:
            if dtrust is not None:
                scored = [(idx, u * dtrust.rank_score(idx), u) for idx, u in pool]
            else:
                scored = [(idx, u * trust.rank_score(idx), u) for idx, u in pool]
        else:
            scored = [(idx, u, u) for idx, u in pool]
        scored.sort(key=lambda x: -x[1])
        return scored

    def award_next(task, tick, attempt, forced_winner=None):
        nonlocal dbg_rerank_changed, dbg_rerank_total
        if forced_winner is not None:
            winner_idx = forced_winner
            already_tried = task.extra.get("tried", set())
            already_tried.add(winner_idx)
            task.extra["tried"] = already_tried
        else:
            ranked = rank_pool(task)
            already_tried = task.extra.get("tried", set())
            candidates = [c for c in ranked if c[0] not in already_tried and robots[c[0]].state == "idle"]
            if not candidates:
                task.extra["tried"] = set()
                start_announce(task, tick)
                return
            if protocol == "tgpr" and len(candidates) > 1:
                dbg_rerank_total += 1
                by_raw = sorted(candidates, key=lambda x: -x[2])
                if by_raw[0][0] != candidates[0][0]:
                    dbg_rerank_changed += 1
            winner_idx = candidates[0][0]
            already_tried.add(winner_idx)
            task.extra["tried"] = already_tried
        r = robots[winner_idx]
        dist = r.dist_to_base(BASE_POS)
        delivered, delay, p = send(dist, winner_idx, "down")

        if protocol == "tgpr" and use_adaptive_timeout:
            timeout = (dtrust if dtrust is not None else trust).timeout_for(winner_idx)
            dbg_timeouts.append(timeout)
        elif protocol == "backoff":
            timeout = int(FIXED_ACK_TIMEOUT * (BACKOFF_MULT ** attempt))
        else:
            timeout = FIXED_ACK_TIMEOUT
        ack_deadline = tick + timeout

        if dtrust is not None:
            dtrust.update_down(winner_idx, delivered)

        task.status = "awaiting_ack"
        task.holder = winner_idx
        task.ack_deadline = ack_deadline
        task.reassign_attempts = attempt
        task.extra["award_sent_tick"] = tick
        task.extra["award_delivered"] = delivered
        if protocol == "cbba":
            task.extra["cbba_best_utility"] = max(task.extra.get("cbba_best_utility", -1.0), utility(r, task))

        award_broadcast_deadline[task.tid] = (winner_idx, ack_deadline)
        confirm_overheard.setdefault(task.tid, set())
        if protocol == "tgpr" and use_bystander:
            for (bidx, _score, _u) in ranked:
                if bidx == winner_idx or robots[bidx].state != "idle":
                    continue
                bdist = robots[bidx].dist_to_base(BASE_POS)
                bdeliv, bdelay, bp = send(bdist, bidx, "down")
                if bdeliv:
                    confirm_overheard[task.tid].add(bidx)

        if delivered:
            r.state = "executing"
            r.assigned_task = task.tid
            r.target = task.loc.copy()
            travel_ticks = max(1, int(np.linalg.norm(r.pos - task.loc) / ROBOT_SPEED))
            finish_tick = tick + delay + travel_ticks + SERVICE_TIME
            executors.setdefault(task.tid, []).append(
                {"ridx": winner_idx, "finish_tick": finish_tick, "status": "pending"})
            adeliv, adelay, ap = send(dist, winner_idx, "up")
            ack_arrival = tick + delay + adelay
            task.extra["ack_scheduled"] = (winner_idx, adeliv, ack_arrival)
        else:
            task.extra["ack_scheduled"] = None

    def process_ack_arrivals(tick):
        for task in list(tasks.values()):
            if task.status != "awaiting_ack":
                continue
            sched = task.extra.get("ack_scheduled")
            if sched is None:
                continue
            ridx, delivered, arrival = sched
            if arrival == tick:
                if delivered and ridx == task.holder:
                    observed_delay = arrival - task.extra["award_sent_tick"]
                    if protocol == "tgpr":
                        if dtrust is not None:
                            dtrust.update_up(ridx, True, observed_delay)
                        else:
                            trust.update_success(ridx, observed_delay)
                    task.status = "confirmed"
                    task.confirmed_tick = tick
                    latencies.append(tick - task.created)
                task.extra["ack_scheduled"] = None

    def handle_ack_timeout(task, tick):
        ridx = task.holder
        if protocol == "tgpr":
            if dtrust is not None:
                if task.extra.get("award_delivered"):
                    dtrust.update_up(ridx, False)
                # if the award itself was never delivered, the down failure was
                # already registered at send time in award_next; no up-hop
                # attempt occurred, so no up-hop update is made here.
            else:
                trust.update_failure(ridx)
        # attempt to recall the (possibly still-executing) old holder before moving on
        r = robots[ridx]
        if r.assigned_task == task.tid and r.state == "executing":
            try_cancel(ridx, task.tid, tick)
        if task.reassign_attempts < MAX_REASSIGN:
            award_next(task, tick, attempt=task.reassign_attempts + 1)
        else:
            task.extra["tried"] = set()
            start_announce(task, tick)

    def bystander_unsolicited_claims(tick):
        nonlocal dbg_bystander_claims
        if protocol != "tgpr" or not use_bystander:
            return
        for tid, (winner_idx, deadline) in list(award_broadcast_deadline.items()):
            task = tasks.get(tid)
            if task is None or task.status != "awaiting_ack" or tick < deadline:
                continue
            heard = confirm_overheard.get(tid, set())
            for bidx in list(heard):
                br = robots[bidx]
                if br.state != "idle":
                    heard.discard(bidx)
                    continue
                dist = br.dist_to_base(BASE_POS)
                delivered, delay, p = send(dist, bidx, "down")
                if delivered:
                    old_holder = task.holder
                    if old_holder is not None and old_holder != bidx:
                        old_r = robots[old_holder]
                        if old_r.assigned_task == tid and old_r.state == "executing":
                            try_cancel(old_holder, tid, tick)
                    br.state = "executing"
                    br.assigned_task = tid
                    br.target = task.loc.copy()
                    travel_ticks = max(1, int(np.linalg.norm(br.pos - task.loc) / ROBOT_SPEED))
                    finish_tick = tick + travel_ticks + SERVICE_TIME
                    executors.setdefault(tid, []).append(
                        {"ridx": bidx, "finish_tick": finish_tick, "status": "pending"})
                    task.status = "confirmed"
                    task.holder = bidx
                    task.confirmed_tick = tick
                    latencies.append(tick - task.created)
                    dbg_bystander_claims += 1
                heard.discard(bidx)
                break  # one successful bystander claim per task per tick is enough
            confirm_overheard[tid] = heard

    def cbba_consensus_check(tick):
        """CBBA-style continuous consensus: any idle robot within range that has not
        yet bid on an open task may submit a bid at any point while the task is open
        (awaiting_bids or awaiting_ack), not just during the initial bid window. A bid
        exceeding the current best-known utility outbids the provisional holder: the
        coordinator attempts to cancel the old holder and awards the task to the new
        bidder directly, mirroring CBBA's outbid-and-release consensus dynamic within
        our star-topology channel model."""
        nonlocal dbg_bystander_claims
        if protocol != "cbba":
            return
        open_tasks = [t for t in tasks.values() if t.status in ("awaiting_bids", "awaiting_ack")]
        if not open_tasks:
            return
        idle_robots = [r for r in robots if r.state == "idle"]
        if not idle_robots:
            return
        for task in open_tasks:
            already = task.extra.setdefault("cbba_bid_from", set())
            outbid_count = task.extra.get("outbid_count", 0)
            for r in idle_robots:
                if r.idx in already:
                    continue
                dist = r.dist_to_base(BASE_POS)
                if dist > COMM_RANGE:
                    continue
                u = utility(r, task)
                if u <= 0.05:
                    continue
                already.add(r.idx)
                delivered, delay, p = send(dist, r.idx, "up")
                if not delivered:
                    continue
                current_best = task.extra.get("cbba_best_utility", -1.0)
                if u <= current_best:
                    continue
                if task.status == "awaiting_bids":
                    task.extra.setdefault("pool", []).append((r.idx, u))
                    task.extra["cbba_best_utility"] = u
                elif task.status == "awaiting_ack" and task.holder != r.idx and outbid_count < MAX_OUTBID:
                    old_holder = task.holder
                    old_r = robots[old_holder] if old_holder is not None else None
                    if old_r is not None and old_r.assigned_task == task.tid and old_r.state == "executing":
                        try_cancel(old_holder, task.tid, tick)
                    task.extra["outbid_count"] = outbid_count + 1
                    award_next(task, tick, attempt=task.reassign_attempts, forced_winner=r.idx)
                    dbg_bystander_claims += 1  # reuse counter: "consensus outbid events" for cbba
                    break  # one outbid per task per tick

    def process_cancels(tick):
        for (arrival, ridx, tid) in list(scheduled_cancels):
            if arrival != tick:
                continue
            scheduled_cancels.remove((arrival, ridx, tid))
            r = robots[ridx]
            for e in executors.get(tid, []):
                if e["ridx"] == ridx and e["status"] == "pending":
                    e["status"] = "cancelled"
                    if r.assigned_task == tid:
                        r.state = "idle"
                        r.assigned_task = None
                    break

    def resolve_duplicates_and_completions(tick):
        nonlocal duplicate_count, wasted_exec_ticks
        for tid, execs in executors.items():
            task = tasks.get(tid)
            for e in execs:
                if e["status"] == "pending" and e["finish_tick"] == tick:
                    e["status"] = "finished"
                    r = robots[e["ridx"]]
                    if r.assigned_task == tid:
                        r.state = "idle"
                        r.assigned_task = None
                    if task is not None:
                        finished_so_far = [x for x in execs if x["status"] == "finished"]
                        if task.status != "completed":
                            task.status = "completed"
                            task.completed_tick = tick
                        else:
                            wasted_exec_ticks += SERVICE_TIME
                        if len(finished_so_far) > 1 and not task.duplicate:
                            task.duplicate = True
                            duplicate_count += 1

    tick = 0
    while tick < MAX_TICKS:
        channel.step_jamming()

        for r in robots:
            if r.state == "idle":
                step = rng.normal(0, 1.2, size=2)
                r.pos = np.clip(r.pos + step, 0, FIELD_SIZE)
            elif r.state == "executing" and r.target is not None:
                direction = r.target - r.pos
                dist = np.linalg.norm(direction)
                if dist > 1e-6:
                    move = direction / dist * min(ROBOT_SPEED, dist)
                    r.pos = r.pos + move

        if n_arrived < M_TOTAL_TASKS and rng.random() < TASK_ARRIVAL_P:
            loc = rng.uniform(0, FIELD_SIZE, size=2)
            t = rng.integers(0, 3)
            base_profile = np.array([
                [1.0, 0.3, 0.3], [0.3, 1.0, 0.4], [0.4, 0.3, 1.0]])[t]
            req = np.clip(base_profile + rng.normal(0, 0.15, size=CAP_DIM), 0, 1.3)
            task = Task(next_tid, loc, req, tick, tick + deadline_ticks)
            tasks[next_tid] = task
            next_tid += 1
            n_arrived += 1
            start_announce(task, tick)

            if trace_log is not None:
                p_hats = np.array([trust.p_hat(i) for i in range(n_robots)])
                timeouts = np.array([trust.timeout_for(i) for i in range(n_robots)])
                trace_log.append((
                    tick,
                    float(p_hats[~is_degraded].mean()) if (~is_degraded).any() else np.nan,
                    float(p_hats[is_degraded].mean()) if is_degraded.any() else np.nan,
                    float(timeouts[~is_degraded].mean()) if (~is_degraded).any() else np.nan,
                    float(timeouts[is_degraded].mean()) if is_degraded.any() else np.nan,
                ))

        for task in list(tasks.values()):
            if task.status == "awaiting_bids" and tick >= task.bid_window_end:
                finalize_bidding(task, tick)

        process_ack_arrivals(tick)
        bystander_unsolicited_claims(tick)
        cbba_consensus_check(tick)

        if protocol == "periodic":
            if tick % PERIODIC_SYNC == 0:
                for task in list(tasks.values()):
                    if task.status == "awaiting_ack" and tick >= task.ack_deadline:
                        handle_ack_timeout(task, tick)
        else:
            grace = TGPR_BYSTANDER_GRACE if (protocol == "tgpr" and use_bystander) else 0
            for task in list(tasks.values()):
                if task.status == "awaiting_ack" and tick >= task.ack_deadline + grace:
                    handle_ack_timeout(task, tick)

        process_cancels(tick)
        resolve_duplicates_and_completions(tick)

        for task in list(tasks.values()):
            if task.status not in ("completed", "expired") and tick >= task.deadline:
                task.status = "expired"
                if task.holder is not None and robots[task.holder].assigned_task == task.tid:
                    robots[task.holder].state = "idle"
                    robots[task.holder].assigned_task = None

        unresolved = any(t.status not in ("completed", "expired") for t in tasks.values())
        if n_arrived >= M_TOTAL_TASKS and not unresolved:
            break
        tick += 1

    total = len(tasks)
    starved = sum(1 for t in tasks.values() if t.status == "expired")
    completed = sum(1 for t in tasks.values() if t.status == "completed")
    dup_rate = duplicate_count / completed if completed > 0 else 0.0

    half = total // 2
    early = [t for t in tasks.values() if t.tid < half]
    late = [t for t in tasks.values() if t.tid >= half]
    early_comp = sum(1 for t in early if t.status == "completed") / len(early) if early else np.nan
    late_comp = sum(1 for t in late if t.status == "completed") / len(late) if late else np.nan

    return dict(
        protocol=protocol, scenario=scenario, n_robots=n_robots, seed=seed,
        total_tasks=total, completed=completed, expired=starved,
        completion_rate=completed / total if total else 0.0,
        starvation_rate=starved / total if total else 0.0,
        duplicate_rate=dup_rate,
        mean_latency=float(np.mean(latencies)) if latencies else np.nan,
        median_latency=float(np.median(latencies)) if latencies else np.nan,
        total_messages=total_msgs,
        msgs_per_completed=total_msgs / completed if completed > 0 else np.nan,
        wasted_exec_ticks=wasted_exec_ticks,
        episode_ticks=tick,
        early_completion_rate=early_comp,
        late_completion_rate=late_comp,
        trace=trace_log,
        **(dict(
            dbg_mean_pool_size=float(np.mean(dbg_pool_sizes)) if dbg_pool_sizes else np.nan,
            dbg_rerank_changed=dbg_rerank_changed,
            dbg_rerank_total=dbg_rerank_total,
            dbg_mean_timeout=float(np.mean(dbg_timeouts)) if dbg_timeouts else np.nan,
            dbg_bystander_claims=dbg_bystander_claims,
            dbg_cancels_sent=dbg_cancels_sent,
            dbg_cancels_delivered=dbg_cancels_delivered,
            dbg_final_p_hat=(trust.p_hat(np.arange(n_robots)).tolist() if trust is not None else None),
            dbg_reliability=reliability_factors.tolist(),
        ) if debug else {})
    )
